import numpy as np
import pandas as pd
import math

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
import joblib

import doping_tools  # we use your existing physics functions


# ---------- 1. Generate synthetic data ----------
rho_values = np.logspace(-3, 3, 500)  # 10^-3 ... 10^3 ohm·cm

rows = []
for rho in rho_values:
    # n-type
    N_n = doping_tools.doping_from_resistivity(rho, "n")
    rows.append({"rho": rho, "dopant_type": 0, "N_doping": N_n})

    # p-type
    N_p = doping_tools.doping_from_resistivity(rho, "p")
    rows.append({"rho": rho, "dopant_type": 1, "N_doping": N_p})

df = pd.DataFrame(rows)

# ---------- 2. Log10 features ----------
df["log_rho"] = np.log10(df["rho"])
df["log_N"] = np.log10(df["N_doping"])

X = df[["log_rho", "dopant_type"]]
y = df["log_N"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ---------- 3. Train model ----------
model = RandomForestRegressor(
    n_estimators=300,
    random_state=42
)

model.fit(X_train, y_train)

y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("MAE in log10(N):", mae)
print("R^2:", r2)

# ---------- 4. Save model ----------
joblib.dump(model, "doping_model.joblib")
print("Saved model as doping_model.joblib")
