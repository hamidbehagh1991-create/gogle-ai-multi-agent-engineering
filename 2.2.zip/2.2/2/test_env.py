from dotenv import load_dotenv
import os

load_dotenv()

print("DISCORD_TOKEN set:", bool(os.getenv("DISCORD_TOKEN")))
print("OPENAI_API_KEY set:", bool(os.getenv("OPENAI_API_KEY")))
print("GOOGLE_API_KEY set:", bool(os.getenv("GOOGLE_API_KEY")))
