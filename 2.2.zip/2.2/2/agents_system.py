# agents_system.py

import os
from dotenv import load_dotenv

from comsol_controller import (
    run_simulation,
    analyze_results,
    suggest_new_params,
    parse_error_log,
)

from google.adk.agents import Agent
from google.adk.models.google_llm import Gemini
from google.adk.runners import InMemoryRunner

load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if GOOGLE_API_KEY is None:
    raise RuntimeError("GOOGLE_API_KEY missing in .env")

retry_config = None

# -------- Tools --------
def tool_run_simulation(params: dict) -> dict:
    results = run_simulation(params)
    results["params"] = params
    return results

def tool_analyze(results: dict) -> str:
    return analyze_results(results)

def tool_optimize(results: dict) -> dict:
    return suggest_new_params(results)

def tool_parse(log: str) -> str:
    return parse_error_log(log)

# -------- Agents --------
MODEL_NAME = "models/gemini-1.0-pro"

simulation_agent = Agent(
    name="simulation_agent",
    model=Gemini(model=MODEL_NAME),
    instruction="Run COMSOL simulations with Vb, Rc, Re.",
    tools=[tool_run_simulation],
)

analyzer_agent = Agent(
    name="analyzer_agent",
    model=Gemini(model=MODEL_NAME),
    instruction="Explain COMSOL simulation results.",
    tools=[tool_analyze],
)

optimizer_agent = Agent(
    name="optimizer_agent",
    model=Gemini(model=MODEL_NAME),
    instruction="Optimize amplifier parameters.",
    tools=[tool_run_simulation, tool_optimize],
)

errorfix_agent = Agent(
    name="errorfix_agent",
    model=Gemini(model=MODEL_NAME),
    instruction="Fix COMSOL model errors.",
    tools=[tool_parse],
)

coordinator_agent = Agent(
    name="coordinator",
    model=Gemini(model=MODEL_NAME),
    instruction=(
        "You decide whether to simulate, analyze, optimize, or debug. "
        "Guide the user and call the correct sub-agent."
    ),
)

runner = InMemoryRunner(root_agent=coordinator_agent)

async def chat_with_system(message: str):
    return await runner.run_debug(message)
