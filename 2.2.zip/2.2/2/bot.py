# bot.py
import os
import math
import joblib

import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv

import numpy as np  # optional
import matplotlib.pyplot as plt  # optional

import doping_tools
from comsol_controller import run_simulation, analyze_results  # 👈 COMSOL automation

from google import genai  # NEW Gemini SDK

bot.strip_after_register = True

@bot.event
async def on_ready():
    print(f"Bot is online as {bot.user}")
    synced = await bot.tree.sync()
    print("Slash commands synced:", synced)

# -------------------------------------------------------------------
# 1) Load environment variables
# -------------------------------------------------------------------
load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

if not DISCORD_TOKEN:
    raise RuntimeError("DISCORD_TOKEN is not set in .env")
if not GOOGLE_API_KEY:
    raise RuntimeError("GOOGLE_API_KEY is not set in .env")


# -------------------------------------------------------------------
# 2) Configure Gemini (google-genai client)
# -------------------------------------------------------------------
gemini_client = genai.Client(api_key=GOOGLE_API_KEY)

# Fast and modern model
GEMINI_MODEL = "gemini-2.5-flash"


# -------------------------------------------------------------------
# 3) Discord bot setup
# -------------------------------------------------------------------
intents = discord.Intents.default()
intents.message_content = True  # IMPORTANT: also enable in Developer Portal!

bot = commands.Bot(command_prefix="!", intents=intents)


# -------------------------------------------------------------------
# 4) Load ML model for doping prediction
# -------------------------------------------------------------------
MODEL = joblib.load("doping_model.joblib")


def predict_doping_ml(rho: float, dopant_type_str: str) -> float:
    """Use your trained ML model to predict doping concentration."""
    dopant_type = 0 if dopant_type_str.lower() == "n" else 1
    log_rho = math.log10(rho)
    log_N_pred = MODEL.predict([[log_rho, dopant_type]])[0]
    return 10 ** log_N_pred


# -------------------------------------------------------------------
# 5) Helpers: Gemini + Discord length
# -------------------------------------------------------------------
MAX_DISCORD_CHARS = 1900  # under 2000 character limit


def shorten_for_discord(text: str) -> str:
    """Ensure message fits into a single Discord message."""
    if len(text) <= MAX_DISCORD_CHARS:
        return text
    return text[:MAX_DISCORD_CHARS] + "\n\n… _(truncated to fit Discord limit)_"


def gemini_explain(prompt_text: str) -> str:
    """Ask Gemini to explain something."""
    prompt = (
        "You are a helpful semiconductor physics tutor for a master's student "
        "in micro- and nanotechnology. Explain clearly, with formulas when useful.\n\n"
        f"{prompt_text}"
    )

    resp = gemini_client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
    )
    return resp.text.strip()


# -------------------------------------------------------------------
# 6) Events & global error handler
# -------------------------------------------------------------------
@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"✅ Bot is online as {bot.user}")


@bot.event
async def on_command_error(ctx, error):
    """Print all command errors to console and show short message."""
    print("COMMAND ERROR:", repr(error))
    try:
        await ctx.send(f"⚠️ Error: `{error}`")
    except Exception:
        pass


# -------------------------------------------------------------------
# 7) Prefix commands: !hello, !ping, !ask
# -------------------------------------------------------------------
@bot.command()
async def hello(ctx):
    await ctx.send("Hello! 👋 The bot is running with Gemini now.")


@bot.command()
async def ping(ctx):
    await ctx.send("pong!")


@bot.command()
async def ask(ctx, *, question: str):
    """Free-form chat with Gemini: !ask <question>"""
    try:
        answer = gemini_explain(question)
        answer = shorten_for_discord(answer)
        await ctx.send(answer)
    except Exception as e:
        print("ASK ERROR:", e)
        await ctx.send(f"⚠️ Gemini error: `{e}`")


# -------------------------------------------------------------------
# 8) Slash commands (doping tools)
# -------------------------------------------------------------------
@bot.tree.command(
    name="explain_doping",
    description="Explain a semiconductor doping topic using Gemini.",
)
@app_commands.describe(
    topic="e.g. 'pn junction', 'BJT', 'depletion region', etc."
)
async def explain_doping(interaction: discord.Interaction, topic: str):
    await interaction.response.defer()
    try:
        explanation = gemini_explain(f"Topic: {topic}")
        msg = f"📘 **Explanation for:** `{topic}`\n\n{explanation}"
        msg = shorten_for_discord(msg)
        await interaction.followup.send(msg)
    except Exception as e:
        print("EXPLAIN_DOPING ERROR:", e)
        await interaction.followup.send(f"⚠️ Gemini Error:\n`{e}`")


@bot.tree.command(
    name="doping_ml",
    description="Predict doping using the ML model (ρ + type).",
)
@app_commands.describe(
    resistivity="Resistivity in ohm·cm",
    dopant_type="Doping type: n or p",
)
async def doping_ml(
    interaction: discord.Interaction,
    resistivity: float,
    dopant_type: str = "n",
):
    try:
        N_ml = predict_doping_ml(resistivity, dopant_type)
        label = doping_tools.classify_doping_level(N_ml)
        n_text = doping_tools.format_scientific(N_ml)
        await interaction.response.send_message(
            f"🤖 **ML prediction**\n"
            f"- ρ = `{resistivity} Ω·cm`\n"
            f"- type = `{dopant_type}`\n"
            f"- N ≈ **{n_text}** ({label})"
        )
    except Exception as e:
        print("DOPING_ML ERROR:", e)
        await interaction.response.send_message(f"⚠️ Error in ML prediction: `{e}`")


@bot.tree.command(
    name="doping_calc",
    description="Calculate doping from resistivity using physics formulas.",
)
@app_commands.describe(
    resistivity="Resistivity in ohm·cm",
    dopant_type="Doping type: n or p",
)
async def doping_calc(
    interaction: discord.Interaction,
    resistivity: float,
    dopant_type: str = "n",
):
    try:
        N = doping_tools.doping_from_resistivity(resistivity, dopant_type)
        label = doping_tools.classify_doping_level(N)
        n_text = doping_tools.format_scientific(N)
        await interaction.response.send_message(
            f"🧮 **Physics-based calculation**\n"
            f"- ρ = `{resistivity} Ω·cm`\n"
            f"- type = `{dopant_type}`\n"
            f"- N ≈ **{n_text}** ({label})"
        )
    except Exception as e:
        print("DOPING_CALC ERROR:", e)
        await interaction.response.send_message(f"⚠️ Error: `{e}`")


# -------------------------------------------------------------------
# 9) NEW: Slash command for COMSOL BJT simulation
# -------------------------------------------------------------------
@bot.tree.command(
    name="bjt_sim",
    description="Run a COMSOL BJT amplifier simulation (Vb, Rc, Re).",
)
@app_commands.describe(
    vb="Base voltage in volts",
    rc="Collector resistor Rc in ohms",
    re="Emitter resistor Re in ohms",
)
async def bjt_sim(
    interaction: discord.Interaction,
    vb: float,
    rc: float,
    re: float,
):
    """
    Runs COMSOL via run_simulation(params) and reports Ic, Vout, gain.
    Uses your comsol_controller.py.
    """
    await interaction.response.defer()
    try:
        params = {"Vb": vb, "Rc": rc, "Re": re}
        results = run_simulation(params)  # 👈 COMSOL is called here
        summary = analyze_results(results)

        Ic = results.get("Ic", float("nan"))
        Vout = results.get("Vout", float("nan"))
        gain = results.get("gain", float("nan"))

        msg = (
            "🔧 **COMSOL BJT simulation finished**\n"
            f"- Vb = `{vb} V`\n"
            f"- Rc = `{rc} Ω`\n"
            f"- Re = `{re} Ω`\n\n"
            f"Results:\n"
            f"- Ic ≈ `{Ic:.3e} A`\n"
            f"- Vout ≈ `{Vout:.2f} V`\n"
            f"- Gain ≈ `{gain:.1f}`\n\n"
            f"Explanation:\n{summary}"
        )
        msg = shorten_for_discord(msg)
        await interaction.followup.send(msg)
    except Exception as e:
        print("BJT_SIM ERROR:", e)
        await interaction.followup.send(f"⚠️ COMSOL / simulation error: `{e}`")


# -------------------------------------------------------------------
# 10) Run the bot
# -------------------------------------------------------------------
if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
