# doping_tools.py
import math

# physical constants
Q = 1.602e-19  # elementary charge [C]

# typical room-temperature electron/hole mobilities in Si [cm^2 / (V·s)]
MU_N_CM2 = 1350.0  # electrons
MU_P_CM2 = 480.0   # holes


def doping_from_resistivity(rho_ohm_cm: float, dopant_type: str = "n") -> float:
    """
    Estimate doping concentration from resistivity for silicon.

    Parameters:
        rho_ohm_cm : resistivity in ohm·cm (scalar)
        dopant_type: "n" or "p"

    Returns:
        N_doping in 1/cm^3
    """
    if rho_ohm_cm <= 0:
        raise ValueError("Resistivity must be positive.")

    dopant_type = dopant_type.lower().strip()

    if dopant_type == "n":
        mu = MU_N_CM2
    elif dopant_type == "p":
        mu = MU_P_CM2
    else:
        raise ValueError("dopant_type must be 'n' or 'p'.")

    # N = 1 / (q * μ * ρ)
    N = 1.0 / (Q * mu * rho_ohm_cm)
    return N


def classify_doping_level(N_cm3: float) -> str:
    """
    Rough classification of doping level based on concentration.
    """
    if N_cm3 < 1e14:
        return "very lightly doped"
    elif N_cm3 < 1e16:
        return "lightly doped"
    elif N_cm3 < 1e18:
        return "moderately doped"
    else:
        return "heavily doped"


def format_scientific(N_cm3: float) -> str:
    """
    Format numbers like 1.23 × 10^16 cm⁻³
    """
    if N_cm3 <= 0:
        return "0 cm⁻³"
    exp = int(math.floor(math.log10(N_cm3)))
    mantissa = N_cm3 / (10 ** exp)
    return f"{mantissa:.2f} × 10^{exp} cm⁻³"
