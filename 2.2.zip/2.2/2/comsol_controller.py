# comsol_controller.py
"""
COMSOL / BJT controller for your Discord bot.

- Calls COMSOL 6.3 in batch mode (comsolbatch.exe)
- Passes parameters Vb, Rc, Re to the model
- Expects the model to export a text file 'bjt_results.txt'
  containing one row with Ic, Vout, Gain.
- If COMSOL fails, falls back to an analytic mock model so the bot
  still replies.

You only need to adjust:
  * STUDY_NAME           (if your study is not 'std1')
  * EXPORT_NAME          (if your export is not 'bjt_export')
  * The COMSOL_BIN path  (already set for your install)
"""

import subprocess
from pathlib import Path
from dataclasses import dataclass


# ---------------------------------------------------------------------
# 1) Paths and COMSOL setup
# ---------------------------------------------------------------------

# Your COMSOL 6.3 batch executable (from your screenshot)
COMSOL_BIN = Path(r"D:\Software\Comsol63\Multiphysics\bin\win64\comsolbatch.exe")

# BJT model file (you copied & renamed it to this)
MODEL_PATH = Path(__file__).parent / "bjt_model.mph"

# Working directory for logs & COMSOL outputs
WORK_DIR = Path(__file__).parent / "comsol_runs"
WORK_DIR.mkdir(exist_ok=True)

# Result file that COMSOL should export (via Export → Data → bjt_export)
RESULT_TXT = WORK_DIR / "bjt_results.txt"
LOG_FILE = WORK_DIR / "bjt_log.txt"

# Names used inside the COMSOL model
STUDY_NAME = "std1"        # adapt if your study has another name
EXPORT_NAME = "bjt_export" # adapt if your export node has another name


# ---------------------------------------------------------------------
# 2) Data container
# ---------------------------------------------------------------------

@dataclass
class BJTResult:
    Ic: float
    Vout: float
    gain: float
    params: dict
    comsol_ok: bool = False
    raw_error: str | None = None


# ---------------------------------------------------------------------
# 3) Main function: run_simulation
# ---------------------------------------------------------------------

def run_simulation(params: dict) -> dict:
    """
    Run a BJT simulation with COMSOL (if possible).

    Expected keys in params:
        Vb : base voltage [V]
        Rc : collector resistor [ohm]
        Re : emitter resistor [ohm]

    Returns a dict with:
        Ic, Vout, gain, params, comsol_ok, raw_error
    """
    # ensure result file from previous runs does not confuse us
    if RESULT_TXT.exists():
        RESULT_TXT.unlink(missing_ok=True)

    vb = float(params.get("Vb", 0.7))
    rc = float(params.get("Rc", 1e3))
    re = float(params.get("Re", 100.0))

    try:
        # Build COMSOL batch command
        # Note: -param syntax is: "name=value,name=value,..."
        cmd = [
            str(COMSOL_BIN),
            "-inputfile", str(MODEL_PATH),
            "-outputfile", str(WORK_DIR / "bjt_output.mph"),
            "-batchlog", str(LOG_FILE),
            "-study", STUDY_NAME,
            "-param", f"Vb={vb},Rc={rc},Re={re}",
            "-export", EXPORT_NAME,
        ]

        # Run COMSOL in batch mode
        completed = subprocess.run(
            cmd,
            cwd=WORK_DIR,
            capture_output=True,
            text=True,
            timeout=600,   # 10 minutes max
            check=False,
        )

        if completed.returncode != 0:
            raise RuntimeError(
                f"COMSOL exited with code {completed.returncode}:\n"
                f"{completed.stderr}"
            )

        if not RESULT_TXT.exists():
            raise FileNotFoundError(
                f"Expected result file {RESULT_TXT} was not created. "
                "Check the export node name and path in the .mph model."
            )

        # Parse Ic, Vout, Gain from the text file
        Ic, Vout, gain = _parse_result_file(RESULT_TXT)

        res = BJTResult(
            Ic=Ic,
            Vout=Vout,
            gain=gain,
            params={"Vb": vb, "Rc": rc, "Re": re},
            comsol_ok=True,
        )

        return {
            "Ic": res.Ic,
            "Vout": res.Vout,
            "gain": res.gain,
            "params": res.params,
            "comsol_ok": res.comsol_ok,
            "raw_error": res.raw_error,
        }

    except Exception as e:
        # Anything fails → fall back to mock analytic model
        mock = _mock_bjt_model({"Vb": vb, "Rc": rc, "Re": re})
        mock.comsol_ok = False
        mock.raw_error = str(e)
        return {
            "Ic": mock.Ic,
            "Vout": mock.Vout,
            "gain": mock.gain,
            "params": mock.params,
            "comsol_ok": mock.comsol_ok,
            "raw_error": mock.raw_error,
        }


# ---------------------------------------------------------------------
# 4) Parse COMSOL result text file
# ---------------------------------------------------------------------

def _parse_result_file(path: Path) -> tuple[float, float, float]:
    """
    Parse the exported data file from COMSOL.

    Expected format (from a Global Evaluation → Data export):

        % some comment lines ...
        % ...
        Ic   Vout   Gain
        1.23E-3  5.60  -80.1

    We:
      * ignore lines starting with '%'
      * take the last non-comment line as numeric data
    """
    Ic = Vout = gain = float("nan")
    with path.open("r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f.readlines()]

    data_line = None
    for ln in lines:
        if not ln or ln.startswith("%"):
            continue
        # skip header line with text
        if "Ic" in ln and "Vout" in ln:
            continue
        data_line = ln  # keep last numeric line

    if data_line is None:
        raise ValueError("Could not find numeric data row in result file.")

    parts = data_line.split()
    if len(parts) < 3:
        raise ValueError(f"Unexpected data row format: {data_line!r}")

    Ic = float(parts[0])
    Vout = float(parts[1])
    gain = float(parts[2])

    return Ic, Vout, gain


# ---------------------------------------------------------------------
# 5) Mock analytic model (fallback)
# ---------------------------------------------------------------------

def _mock_bjt_model(params: dict) -> BJTResult:
    """
    Simple analytic BJT amplifier model used when COMSOL is not available.
    """
    Vb = float(params.get("Vb", 0.7))
    Rc = float(params.get("Rc", 1e3))
    Re = float(params.get("Re", 100.0))

    Vcc = 10.0
    beta = 100.0
    Rb = 10e3
    Vbe_on = 0.7

    Ib = max((Vb - Vbe_on) / Rb, 0.0)
    Ic = beta * Ib
    Ie = Ic

    Vc_drop = Ic * Rc
    Ve_drop = Ie * Re

    Vout = Vcc - Vc_drop
    gain = -Rc / Re if Re != 0 else float("nan")

    return BJTResult(
        Ic=Ic,
        Vout=Vout,
        gain=gain,
        params={"Vb": Vb, "Rc": Rc, "Re": Re},
        comsol_ok=False,
    )


# ---------------------------------------------------------------------
# 6) Human-readable explanation
# ---------------------------------------------------------------------

def analyze_results(results: dict) -> str:
    Ic = results.get("Ic", float("nan"))
    Vout = results.get("Vout", float("nan"))
    gain = results.get("gain", float("nan"))
    params = results.get("params", {})

    Vb = params.get("Vb", "unknown")
    Rc = params.get("Rc", "unknown")
    Re = params.get("Re", "unknown")

    lines = []
    lines.append(
        f"The simulation used: Vb = {Vb} V, Rc = {Rc} Ω, Re = {Re} Ω."
    )
    lines.append(
        f"The resulting collector current is Ic ≈ {Ic:.3e} A and the "
        f"output voltage is Vout ≈ {Vout:.2f} V."
    )
    lines.append(
        f"The approximate small-signal gain is {gain:.1f} "
        "(negative sign indicates an inverting amplifier)."
    )

    if Vout < 1.0:
        region = "saturation (collector nearly at emitter potential)"
    elif Vout > 9.0:
        region = "cut-off (very small collector current)"
    else:
        region = "active region (good for linear amplification)"

    lines.append(f"The transistor is approximately in the **{region}** region.")

    if not results.get("comsol_ok", True):
        err = results.get("raw_error")
        if err:
            lines.append(
                "\nNote: These values are from the analytic fallback model, "
                "because the COMSOL batch call did not complete successfully:\n"
                f"  -> {err}"
            )

    return "\n".join(lines)


# ---------------------------------------------------------------------
# 7) Suggest new parameters (for optimization agents later)
# ---------------------------------------------------------------------

def suggest_new_params(results: dict) -> dict:
    params = dict(results.get("params", {}))
    gain = float(results.get("gain", 0.0))
    Vout = float(results.get("Vout", 5.0))

    Rc = float(params.get("Rc", 1e3))
    target_gain = 80.0

    if abs(gain) < target_gain * 0.8:
        Rc *= 1.2
    elif abs(gain) > target_gain * 1.2 or Vout < 2.0:
        Rc *= 0.8

    params["Rc"] = Rc
    return params


def parse_error_log(log_text: str) -> str:
    if len(log_text) <= 2000:
        return log_text
    return log_text[-2000:]
